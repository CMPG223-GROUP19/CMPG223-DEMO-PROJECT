﻿namespace First_Form
{
    partial class Access_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnChildren = new System.Windows.Forms.Button();
            this.btnDonationTypes = new System.Windows.Forms.Button();
            this.btnDonations = new System.Windows.Forms.Button();
            this.lblAccessForms = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnChildren
            // 
            this.btnChildren.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnChildren.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnChildren.Location = new System.Drawing.Point(148, 172);
            this.btnChildren.Name = "btnChildren";
            this.btnChildren.Size = new System.Drawing.Size(456, 77);
            this.btnChildren.TabIndex = 0;
            this.btnChildren.Text = "Maintain children";
            this.btnChildren.UseVisualStyleBackColor = false;
            this.btnChildren.Click += new System.EventHandler(this.btnChildren_Click);
            // 
            // btnDonationTypes
            // 
            this.btnDonationTypes.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDonationTypes.Location = new System.Drawing.Point(12, 272);
            this.btnDonationTypes.Name = "btnDonationTypes";
            this.btnDonationTypes.Size = new System.Drawing.Size(378, 83);
            this.btnDonationTypes.TabIndex = 1;
            this.btnDonationTypes.Text = "maintain donation types";
            this.btnDonationTypes.UseVisualStyleBackColor = false;
            // 
            // btnDonations
            // 
            this.btnDonations.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDonations.Location = new System.Drawing.Point(396, 272);
            this.btnDonations.Name = "btnDonations";
            this.btnDonations.Size = new System.Drawing.Size(392, 83);
            this.btnDonations.TabIndex = 2;
            this.btnDonations.Text = "receive donations";
            this.btnDonations.UseVisualStyleBackColor = false;
            // 
            // lblAccessForms
            // 
            this.lblAccessForms.AutoSize = true;
            this.lblAccessForms.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccessForms.Location = new System.Drawing.Point(40, 20);
            this.lblAccessForms.Name = "lblAccessForms";
            this.lblAccessForms.Size = new System.Drawing.Size(692, 108);
            this.lblAccessForms.TabIndex = 3;
            this.lblAccessForms.Text = "Access Forms:";
            // 
            // Access_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAccessForms);
            this.Controls.Add(this.btnDonations);
            this.Controls.Add(this.btnDonationTypes);
            this.Controls.Add(this.btnChildren);
            this.Name = "Access_Form";
            this.Text = "Acces_Forms";
            this.Load += new System.EventHandler(this.Acces_Forms_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblAccessForms;
        public System.Windows.Forms.Button btnChildren;
        public System.Windows.Forms.Button btnDonationTypes;
        public System.Windows.Forms.Button btnDonations;
    }
}