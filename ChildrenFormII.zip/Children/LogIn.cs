﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace First_Form
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            String Mpassword = "224641";
            String mUserName = "Linda03";
            String Apassword = "996394";
            String aUserName = "Isabel22";

            String password = txtPassword.Text;
            String username = txtUsername.Text;
            String selectedText = comboBox1.SelectedItem.ToString();
            Access_Form nextForm = new Access_Form();
            if (selectedText == "Manager")
            {
                if (Mpassword == password && mUserName == username)
                {
                    MessageBox.Show("Access granted");

                    LogIn myLogIn = new LogIn();
                    myLogIn.ShowDialog();

                    this.Close();


                }
                else
                {
                    MessageBox.Show("Can not grant access");



                }
            }
            else if (selectedText == "Administrator")
            {
                if (Apassword == password && aUserName == username)
                {

                    MessageBox.Show("Access granted");
                    nextForm.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Can not grant access");
                }

            }
            else
            {
                MessageBox.Show("Select user from comboBox!");
            }

        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            this.Focus();
        }
    }


    }

