﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReceiveDonations
{
    public partial class Donations : Form
    {
        public Donations()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbDepartment.SelectedIndex = 0;
            lblAmount.Text = "Amount:          R";
        }

        private void clear()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmailAddress.Text = "";
            txtPhoneNumber.Text = "";
            txtDescription.Text = "";

            cbDepartment.SelectedIndex = 0;
            lblAmount.Text = "Amount:          R";
            nudAmount.Value = 0;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            DateTime date = DateTime.Today;

            String amount = "";

            if (cbDepartment.SelectedIndex == 0)
            {
                amount = nudAmount.Value.ToString("c");
            }
            else
            {
                amount = nudAmount.Value.ToString();
            }

            String fullName = txtFirstName.Text + " " + txtLastName.Text;
            String department = cbDepartment.SelectedItem.ToString();
            String description = txtDescription.Text;

            lstOutput.Items.Add(fullName + " donated " + amount + " " +
                description.ToLower() + " at " + date.ToLongDateString());

            clear();
        }

        private void cbDescription_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbDepartment.SelectedIndex == 0)
            {
                lblAmount.Text = "Amount:          R";
            }
            else
            {
                lblAmount.Text = "Quantity:";
            }
        }
    }
}
