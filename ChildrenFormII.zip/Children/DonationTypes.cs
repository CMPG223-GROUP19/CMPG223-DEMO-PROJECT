﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Donoation_Types
{
    public partial class DonationTypes : Form
    {
        public DonationTypes()
        {
            InitializeComponent();
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            /*InsertDonationTypes childForm = new InsertDonationTypes();
            childForm.ShowDialog();*/
        }

        private void insertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*InsertDonationTypes childForm = new InsertDonationTypes();
            childForm.MdiParent = this;
            childForm.Show();*/
        }


    }    

}
