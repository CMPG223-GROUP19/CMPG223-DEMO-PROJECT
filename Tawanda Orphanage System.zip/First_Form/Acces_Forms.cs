﻿using Donoation_Types;
using ReceiveDonations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace First_Form
{
    public partial class Acces_Forms : Form
    {
        public Acces_Forms()
        {
            InitializeComponent();
        }

        private void Acces_Forms_Load(object sender, EventArgs e)
        {  
        }


        private void btnChildren_Click(object sender, EventArgs e)
        {
            Children.child form = new Children.child ( );
            form.ShowDialog();
            this.Hide();
        }

        private void btnDonations_Click(object sender, EventArgs e)
        {
            Donations form = new Donations();
            form.ShowDialog();
            this.Hide();
        }

        private void btnDonationTypes_Click(object sender, EventArgs e)
        {
            DonationTypes form = new DonationTypes();
            form.ShowDialog();
            this.Hide();
        }
    }
}
