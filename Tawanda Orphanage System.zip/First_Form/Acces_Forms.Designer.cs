﻿namespace First_Form
{
    partial class Acces_Forms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnChildren = new System.Windows.Forms.Button();
            this.btnDonationTypes = new System.Windows.Forms.Button();
            this.btnDonations = new System.Windows.Forms.Button();
            this.lblAccessForms = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnChildren
            // 
            this.btnChildren.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnChildren.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnChildren.Location = new System.Drawing.Point(197, 212);
            this.btnChildren.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChildren.Name = "btnChildren";
            this.btnChildren.Size = new System.Drawing.Size(608, 95);
            this.btnChildren.TabIndex = 0;
            this.btnChildren.Text = "Maintain children";
            this.btnChildren.UseVisualStyleBackColor = false;
            this.btnChildren.Click += new System.EventHandler(this.btnChildren_Click);
            // 
            // btnDonationTypes
            // 
            this.btnDonationTypes.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDonationTypes.Location = new System.Drawing.Point(16, 335);
            this.btnDonationTypes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDonationTypes.Name = "btnDonationTypes";
            this.btnDonationTypes.Size = new System.Drawing.Size(504, 102);
            this.btnDonationTypes.TabIndex = 1;
            this.btnDonationTypes.Text = "maintain donation types";
            this.btnDonationTypes.UseVisualStyleBackColor = false;
            this.btnDonationTypes.Click += new System.EventHandler(this.btnDonationTypes_Click);
            // 
            // btnDonations
            // 
            this.btnDonations.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDonations.Location = new System.Drawing.Point(528, 335);
            this.btnDonations.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDonations.Name = "btnDonations";
            this.btnDonations.Size = new System.Drawing.Size(523, 102);
            this.btnDonations.TabIndex = 2;
            this.btnDonations.Text = "receive donations";
            this.btnDonations.UseVisualStyleBackColor = false;
            this.btnDonations.Click += new System.EventHandler(this.btnDonations_Click);
            // 
            // lblAccessForms
            // 
            this.lblAccessForms.AutoSize = true;
            this.lblAccessForms.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccessForms.Location = new System.Drawing.Point(53, 25);
            this.lblAccessForms.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAccessForms.Name = "lblAccessForms";
            this.lblAccessForms.Size = new System.Drawing.Size(862, 135);
            this.lblAccessForms.TabIndex = 3;
            this.lblAccessForms.Text = "Access Forms:";
            // 
            // Acces_Forms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.lblAccessForms);
            this.Controls.Add(this.btnDonations);
            this.Controls.Add(this.btnDonationTypes);
            this.Controls.Add(this.btnChildren);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Acces_Forms";
            this.Text = "Acces_Forms";
            this.Load += new System.EventHandler(this.Acces_Forms_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblAccessForms;
        public System.Windows.Forms.Button btnChildren;
        public System.Windows.Forms.Button btnDonationTypes;
        public System.Windows.Forms.Button btnDonations;
    }
}