﻿namespace Children
{
    partial class child
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.gbInsertUpdate = new System.Windows.Forms.GroupBox();
            this.dtmDepart = new System.Windows.Forms.DateTimePicker();
            this.dtmArr = new System.Windows.Forms.DateTimePicker();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblSubmit = new System.Windows.Forms.Button();
            this.cmbAccept = new System.Windows.Forms.ComboBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblIsAccepeted = new System.Windows.Forms.Label();
            this.lblDepart = new System.Windows.Forms.Label();
            this.lblArr = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnNew = new System.Windows.Forms.Button();
            this.gbxDisplay = new System.Windows.Forms.GroupBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.gbSort = new System.Windows.Forms.GroupBox();
            this.rbtnSortDepartDesc = new System.Windows.Forms.RadioButton();
            this.rbtnSortDepart = new System.Windows.Forms.RadioButton();
            this.rbtnSortArrDesc = new System.Windows.Forms.RadioButton();
            this.rbtnSortArr = new System.Windows.Forms.RadioButton();
            this.rbtnSortAgeDesc = new System.Windows.Forms.RadioButton();
            this.rbtnSortAge = new System.Windows.Forms.RadioButton();
            this.rbtnSortLName = new System.Windows.Forms.RadioButton();
            this.gbShow = new System.Windows.Forms.GroupBox();
            this.lblRequired = new System.Windows.Forms.Label();
            this.nmrSortAgeII = new System.Windows.Forms.NumericUpDown();
            this.nmrSortAge = new System.Windows.Forms.NumericUpDown();
            this.dtmSortDepartII = new System.Windows.Forms.DateTimePicker();
            this.dtmSortDepart = new System.Windows.Forms.DateTimePicker();
            this.dtmSortArrII = new System.Windows.Forms.DateTimePicker();
            this.dtmSortArr = new System.Windows.Forms.DateTimePicker();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblAND = new System.Windows.Forms.Label();
            this.lblDepartBtwn = new System.Windows.Forms.Label();
            this.lblArrivedBtwn = new System.Windows.Forms.Label();
            this.lblAgeBtwn = new System.Windows.Forms.Label();
            this.rbtnRejected = new System.Windows.Forms.RadioButton();
            this.rbtnAccepted = new System.Windows.Forms.RadioButton();
            this.rbtnAll = new System.Windows.Forms.RadioButton();
            this.dgvOutput = new System.Windows.Forms.DataGridView();
            this.lblOutput = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.gbInsertUpdate.SuspendLayout();
            this.gbxDisplay.SuspendLayout();
            this.gbSort.SuspendLayout();
            this.gbShow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrSortAgeII)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrSortAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutput)).BeginInit();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(17, 16);
            this.lblHeading.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(286, 25);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "CHILD MANAGEMENT ";
            // 
            // gbInsertUpdate
            // 
            this.gbInsertUpdate.Controls.Add(this.dtmDepart);
            this.gbInsertUpdate.Controls.Add(this.dtmArr);
            this.gbInsertUpdate.Controls.Add(this.btnUpdate);
            this.gbInsertUpdate.Controls.Add(this.lblSubmit);
            this.gbInsertUpdate.Controls.Add(this.cmbAccept);
            this.gbInsertUpdate.Controls.Add(this.txtID);
            this.gbInsertUpdate.Controls.Add(this.txtLastName);
            this.gbInsertUpdate.Controls.Add(this.txtName);
            this.gbInsertUpdate.Controls.Add(this.lblIsAccepeted);
            this.gbInsertUpdate.Controls.Add(this.lblDepart);
            this.gbInsertUpdate.Controls.Add(this.lblArr);
            this.gbInsertUpdate.Controls.Add(this.lblID);
            this.gbInsertUpdate.Controls.Add(this.lblLastName);
            this.gbInsertUpdate.Controls.Add(this.lblName);
            this.gbInsertUpdate.Location = new System.Drawing.Point(39, 82);
            this.gbInsertUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInsertUpdate.Name = "gbInsertUpdate";
            this.gbInsertUpdate.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbInsertUpdate.Size = new System.Drawing.Size(487, 388);
            this.gbInsertUpdate.TabIndex = 1;
            this.gbInsertUpdate.TabStop = false;
            this.gbInsertUpdate.Text = "Insert and Change";
            // 
            // dtmDepart
            // 
            this.dtmDepart.Location = new System.Drawing.Point(187, 171);
            this.dtmDepart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmDepart.Name = "dtmDepart";
            this.dtmDepart.Size = new System.Drawing.Size(265, 22);
            this.dtmDepart.TabIndex = 18;
            // 
            // dtmArr
            // 
            this.dtmArr.Location = new System.Drawing.Point(188, 134);
            this.dtmArr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmArr.Name = "dtmArr";
            this.dtmArr.Size = new System.Drawing.Size(264, 22);
            this.dtmArr.TabIndex = 17;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.SkyBlue;
            this.btnUpdate.Location = new System.Drawing.Point(283, 332);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(171, 44);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblSubmit
            // 
            this.lblSubmit.BackColor = System.Drawing.Color.SkyBlue;
            this.lblSubmit.Location = new System.Drawing.Point(35, 332);
            this.lblSubmit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lblSubmit.Name = "lblSubmit";
            this.lblSubmit.Size = new System.Drawing.Size(160, 44);
            this.lblSubmit.TabIndex = 12;
            this.lblSubmit.Text = "SUBMIT";
            this.lblSubmit.UseVisualStyleBackColor = false;
            this.lblSubmit.Click += new System.EventHandler(this.lblSubmit_Click);
            // 
            // cmbAccept
            // 
            this.cmbAccept.FormattingEnabled = true;
            this.cmbAccept.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbAccept.Location = new System.Drawing.Point(187, 203);
            this.cmbAccept.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbAccept.Name = "cmbAccept";
            this.cmbAccept.Size = new System.Drawing.Size(160, 24);
            this.cmbAccept.TabIndex = 11;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(187, 102);
            this.txtID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(160, 22);
            this.txtID.TabIndex = 8;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(187, 70);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(160, 22);
            this.txtLastName.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(187, 36);
            this.txtName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(160, 22);
            this.txtName.TabIndex = 6;
            // 
            // lblIsAccepeted
            // 
            this.lblIsAccepeted.AutoSize = true;
            this.lblIsAccepeted.Location = new System.Drawing.Point(31, 203);
            this.lblIsAccepeted.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIsAccepeted.Name = "lblIsAccepeted";
            this.lblIsAccepeted.Size = new System.Drawing.Size(89, 16);
            this.lblIsAccepeted.TabIndex = 5;
            this.lblIsAccepeted.Text = "Is Accepeted:";
            // 
            // lblDepart
            // 
            this.lblDepart.AutoSize = true;
            this.lblDepart.Location = new System.Drawing.Point(31, 177);
            this.lblDepart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDepart.Name = "lblDepart";
            this.lblDepart.Size = new System.Drawing.Size(102, 16);
            this.lblDepart.TabIndex = 4;
            this.lblDepart.Text = "Departure Date:";
            this.lblDepart.Click += new System.EventHandler(this.lblDepart_Click);
            // 
            // lblArr
            // 
            this.lblArr.AutoSize = true;
            this.lblArr.Location = new System.Drawing.Point(31, 145);
            this.lblArr.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArr.Name = "lblArr";
            this.lblArr.Size = new System.Drawing.Size(80, 16);
            this.lblArr.TabIndex = 3;
            this.lblArr.Text = "Arrival Date:";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(31, 106);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(103, 16);
            this.lblID.TabIndex = 2;
            this.lblID.Text = "Identity Number:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(31, 70);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(75, 16);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(31, 36);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 16);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.SkyBlue;
            this.btnNew.Location = new System.Drawing.Point(1367, 784);
            this.btnNew.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(137, 52);
            this.btnNew.TabIndex = 19;
            this.btnNew.Text = "CLEAR";
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // gbxDisplay
            // 
            this.gbxDisplay.Controls.Add(this.btnEnter);
            this.gbxDisplay.Controls.Add(this.gbSort);
            this.gbxDisplay.Controls.Add(this.gbShow);
            this.gbxDisplay.Location = new System.Drawing.Point(551, 82);
            this.gbxDisplay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxDisplay.Name = "gbxDisplay";
            this.gbxDisplay.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxDisplay.Size = new System.Drawing.Size(1091, 388);
            this.gbxDisplay.TabIndex = 2;
            this.gbxDisplay.TabStop = false;
            this.gbxDisplay.Text = "Display Records";
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.SkyBlue;
            this.btnEnter.Location = new System.Drawing.Point(816, 332);
            this.btnEnter.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(259, 48);
            this.btnEnter.TabIndex = 14;
            this.btnEnter.Text = "ENTER";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // gbSort
            // 
            this.gbSort.Controls.Add(this.rbtnSortDepartDesc);
            this.gbSort.Controls.Add(this.rbtnSortDepart);
            this.gbSort.Controls.Add(this.rbtnSortArrDesc);
            this.gbSort.Controls.Add(this.rbtnSortArr);
            this.gbSort.Controls.Add(this.rbtnSortAgeDesc);
            this.gbSort.Controls.Add(this.rbtnSortAge);
            this.gbSort.Controls.Add(this.rbtnSortLName);
            this.gbSort.Location = new System.Drawing.Point(819, 49);
            this.gbSort.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbSort.Name = "gbSort";
            this.gbSort.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbSort.Size = new System.Drawing.Size(245, 276);
            this.gbSort.TabIndex = 3;
            this.gbSort.TabStop = false;
            this.gbSort.Text = "Sort By";
            // 
            // rbtnSortDepartDesc
            // 
            this.rbtnSortDepartDesc.AutoSize = true;
            this.rbtnSortDepartDesc.Location = new System.Drawing.Point(20, 215);
            this.rbtnSortDepartDesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortDepartDesc.Name = "rbtnSortDepartDesc";
            this.rbtnSortDepartDesc.Size = new System.Drawing.Size(196, 20);
            this.rbtnSortDepartDesc.TabIndex = 8;
            this.rbtnSortDepartDesc.TabStop = true;
            this.rbtnSortDepartDesc.Text = "Departure Date Descending";
            this.rbtnSortDepartDesc.UseVisualStyleBackColor = true;
            // 
            // rbtnSortDepart
            // 
            this.rbtnSortDepart.AutoSize = true;
            this.rbtnSortDepart.Location = new System.Drawing.Point(20, 187);
            this.rbtnSortDepart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortDepart.Name = "rbtnSortDepart";
            this.rbtnSortDepart.Size = new System.Drawing.Size(187, 20);
            this.rbtnSortDepart.TabIndex = 7;
            this.rbtnSortDepart.TabStop = true;
            this.rbtnSortDepart.Text = "Departure Date Ascending";
            this.rbtnSortDepart.UseVisualStyleBackColor = true;
            // 
            // rbtnSortArrDesc
            // 
            this.rbtnSortArrDesc.AutoSize = true;
            this.rbtnSortArrDesc.Location = new System.Drawing.Point(20, 159);
            this.rbtnSortArrDesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortArrDesc.Name = "rbtnSortArrDesc";
            this.rbtnSortArrDesc.Size = new System.Drawing.Size(174, 20);
            this.rbtnSortArrDesc.TabIndex = 6;
            this.rbtnSortArrDesc.TabStop = true;
            this.rbtnSortArrDesc.Text = "Arrival Date Descending";
            this.rbtnSortArrDesc.UseVisualStyleBackColor = true;
            // 
            // rbtnSortArr
            // 
            this.rbtnSortArr.AutoSize = true;
            this.rbtnSortArr.Location = new System.Drawing.Point(20, 128);
            this.rbtnSortArr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortArr.Name = "rbtnSortArr";
            this.rbtnSortArr.Size = new System.Drawing.Size(165, 20);
            this.rbtnSortArr.TabIndex = 5;
            this.rbtnSortArr.TabStop = true;
            this.rbtnSortArr.Text = "Arrival Date Ascending";
            this.rbtnSortArr.UseVisualStyleBackColor = true;
            // 
            // rbtnSortAgeDesc
            // 
            this.rbtnSortAgeDesc.AutoSize = true;
            this.rbtnSortAgeDesc.Location = new System.Drawing.Point(20, 96);
            this.rbtnSortAgeDesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortAgeDesc.Name = "rbtnSortAgeDesc";
            this.rbtnSortAgeDesc.Size = new System.Drawing.Size(129, 20);
            this.rbtnSortAgeDesc.TabIndex = 4;
            this.rbtnSortAgeDesc.TabStop = true;
            this.rbtnSortAgeDesc.Text = "Age Descending";
            this.rbtnSortAgeDesc.UseVisualStyleBackColor = true;
            // 
            // rbtnSortAge
            // 
            this.rbtnSortAge.AutoSize = true;
            this.rbtnSortAge.Location = new System.Drawing.Point(20, 68);
            this.rbtnSortAge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortAge.Name = "rbtnSortAge";
            this.rbtnSortAge.Size = new System.Drawing.Size(120, 20);
            this.rbtnSortAge.TabIndex = 3;
            this.rbtnSortAge.TabStop = true;
            this.rbtnSortAge.Text = "Age Ascending";
            this.rbtnSortAge.UseVisualStyleBackColor = true;
            // 
            // rbtnSortLName
            // 
            this.rbtnSortLName.AutoSize = true;
            this.rbtnSortLName.Location = new System.Drawing.Point(20, 39);
            this.rbtnSortLName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnSortLName.Name = "rbtnSortLName";
            this.rbtnSortLName.Size = new System.Drawing.Size(93, 20);
            this.rbtnSortLName.TabIndex = 2;
            this.rbtnSortLName.TabStop = true;
            this.rbtnSortLName.Text = "Last Name";
            this.rbtnSortLName.UseVisualStyleBackColor = true;
            this.rbtnSortLName.CheckedChanged += new System.EventHandler(this.rbtnSortLName_CheckedChanged);
            // 
            // gbShow
            // 
            this.gbShow.Controls.Add(this.lblRequired);
            this.gbShow.Controls.Add(this.nmrSortAgeII);
            this.gbShow.Controls.Add(this.nmrSortAge);
            this.gbShow.Controls.Add(this.dtmSortDepartII);
            this.gbShow.Controls.Add(this.dtmSortDepart);
            this.gbShow.Controls.Add(this.dtmSortArrII);
            this.gbShow.Controls.Add(this.dtmSortArr);
            this.gbShow.Controls.Add(this.rbtnMale);
            this.gbShow.Controls.Add(this.rbtnFemale);
            this.gbShow.Controls.Add(this.label3);
            this.gbShow.Controls.Add(this.label2);
            this.gbShow.Controls.Add(this.lblAND);
            this.gbShow.Controls.Add(this.lblDepartBtwn);
            this.gbShow.Controls.Add(this.lblArrivedBtwn);
            this.gbShow.Controls.Add(this.lblAgeBtwn);
            this.gbShow.Controls.Add(this.rbtnRejected);
            this.gbShow.Controls.Add(this.rbtnAccepted);
            this.gbShow.Controls.Add(this.rbtnAll);
            this.gbShow.Location = new System.Drawing.Point(28, 49);
            this.gbShow.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbShow.Name = "gbShow";
            this.gbShow.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbShow.Size = new System.Drawing.Size(756, 276);
            this.gbShow.TabIndex = 0;
            this.gbShow.TabStop = false;
            this.gbShow.Text = "Show";
            // 
            // lblRequired
            // 
            this.lblRequired.AutoSize = true;
            this.lblRequired.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequired.ForeColor = System.Drawing.Color.DarkRed;
            this.lblRequired.Location = new System.Drawing.Point(208, 36);
            this.lblRequired.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRequired.Name = "lblRequired";
            this.lblRequired.Size = new System.Drawing.Size(21, 25);
            this.lblRequired.TabIndex = 25;
            this.lblRequired.Text = "*";
            // 
            // nmrSortAgeII
            // 
            this.nmrSortAgeII.Location = new System.Drawing.Point(161, 177);
            this.nmrSortAgeII.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nmrSortAgeII.Maximum = new decimal(new int[] {
            18,
            0,
            0,
            0});
            this.nmrSortAgeII.Name = "nmrSortAgeII";
            this.nmrSortAgeII.Size = new System.Drawing.Size(265, 22);
            this.nmrSortAgeII.TabIndex = 24;
            // 
            // nmrSortAge
            // 
            this.nmrSortAge.Location = new System.Drawing.Point(483, 177);
            this.nmrSortAge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nmrSortAge.Maximum = new decimal(new int[] {
            18,
            0,
            0,
            0});
            this.nmrSortAge.Name = "nmrSortAge";
            this.nmrSortAge.Size = new System.Drawing.Size(265, 22);
            this.nmrSortAge.TabIndex = 23;
            // 
            // dtmSortDepartII
            // 
            this.dtmSortDepartII.Location = new System.Drawing.Point(483, 235);
            this.dtmSortDepartII.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmSortDepartII.Name = "dtmSortDepartII";
            this.dtmSortDepartII.Size = new System.Drawing.Size(264, 22);
            this.dtmSortDepartII.TabIndex = 22;
            // 
            // dtmSortDepart
            // 
            this.dtmSortDepart.Location = new System.Drawing.Point(161, 238);
            this.dtmSortDepart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmSortDepart.Name = "dtmSortDepart";
            this.dtmSortDepart.Size = new System.Drawing.Size(264, 22);
            this.dtmSortDepart.TabIndex = 21;
            // 
            // dtmSortArrII
            // 
            this.dtmSortArrII.Location = new System.Drawing.Point(483, 207);
            this.dtmSortArrII.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmSortArrII.Name = "dtmSortArrII";
            this.dtmSortArrII.Size = new System.Drawing.Size(264, 22);
            this.dtmSortArrII.TabIndex = 19;
            // 
            // dtmSortArr
            // 
            this.dtmSortArr.Location = new System.Drawing.Point(161, 209);
            this.dtmSortArr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtmSortArr.Name = "dtmSortArr";
            this.dtmSortArr.Size = new System.Drawing.Size(264, 22);
            this.dtmSortArr.TabIndex = 18;
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(23, 151);
            this.rbtnMale.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(140, 20);
            this.rbtnMale.TabIndex = 17;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male Children Only";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(23, 126);
            this.rbtnFemale.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(156, 20);
            this.rbtnFemale.TabIndex = 16;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female Children Only";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(435, 242);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "AND";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(435, 215);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "AND";
            // 
            // lblAND
            // 
            this.lblAND.AutoSize = true;
            this.lblAND.Location = new System.Drawing.Point(435, 183);
            this.lblAND.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAND.Name = "lblAND";
            this.lblAND.Size = new System.Drawing.Size(36, 16);
            this.lblAND.TabIndex = 13;
            this.lblAND.Text = "AND";
            // 
            // lblDepartBtwn
            // 
            this.lblDepartBtwn.AutoSize = true;
            this.lblDepartBtwn.Location = new System.Drawing.Point(19, 242);
            this.lblDepartBtwn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDepartBtwn.Name = "lblDepartBtwn";
            this.lblDepartBtwn.Size = new System.Drawing.Size(122, 16);
            this.lblDepartBtwn.TabIndex = 5;
            this.lblDepartBtwn.Text = "Departed Between:";
            // 
            // lblArrivedBtwn
            // 
            this.lblArrivedBtwn.AutoSize = true;
            this.lblArrivedBtwn.Location = new System.Drawing.Point(21, 214);
            this.lblArrivedBtwn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArrivedBtwn.Name = "lblArrivedBtwn";
            this.lblArrivedBtwn.Size = new System.Drawing.Size(108, 16);
            this.lblArrivedBtwn.TabIndex = 4;
            this.lblArrivedBtwn.Text = "Arrived Between:";
            this.lblArrivedBtwn.Click += new System.EventHandler(this.lblArrivedBtwn_Click);
            // 
            // lblAgeBtwn
            // 
            this.lblAgeBtwn.AutoSize = true;
            this.lblAgeBtwn.Location = new System.Drawing.Point(21, 186);
            this.lblAgeBtwn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAgeBtwn.Name = "lblAgeBtwn";
            this.lblAgeBtwn.Size = new System.Drawing.Size(90, 16);
            this.lblAgeBtwn.TabIndex = 3;
            this.lblAgeBtwn.Text = "Age Between:";
            // 
            // rbtnRejected
            // 
            this.rbtnRejected.AutoSize = true;
            this.rbtnRejected.Location = new System.Drawing.Point(23, 94);
            this.rbtnRejected.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnRejected.Name = "rbtnRejected";
            this.rbtnRejected.Size = new System.Drawing.Size(162, 20);
            this.rbtnRejected.TabIndex = 2;
            this.rbtnRejected.TabStop = true;
            this.rbtnRejected.Text = "Not Accepted Children";
            this.rbtnRejected.UseVisualStyleBackColor = true;
            // 
            // rbtnAccepted
            // 
            this.rbtnAccepted.AutoSize = true;
            this.rbtnAccepted.Location = new System.Drawing.Point(23, 64);
            this.rbtnAccepted.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAccepted.Name = "rbtnAccepted";
            this.rbtnAccepted.Size = new System.Drawing.Size(168, 20);
            this.rbtnAccepted.TabIndex = 1;
            this.rbtnAccepted.TabStop = true;
            this.rbtnAccepted.Text = "Accepted Children Only";
            this.rbtnAccepted.UseVisualStyleBackColor = true;
            // 
            // rbtnAll
            // 
            this.rbtnAll.AutoSize = true;
            this.rbtnAll.Location = new System.Drawing.Point(23, 36);
            this.rbtnAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbtnAll.Name = "rbtnAll";
            this.rbtnAll.Size = new System.Drawing.Size(95, 20);
            this.rbtnAll.TabIndex = 0;
            this.rbtnAll.TabStop = true;
            this.rbtnAll.Text = "All Children";
            this.rbtnAll.UseVisualStyleBackColor = true;
            // 
            // dgvOutput
            // 
            this.dgvOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOutput.Location = new System.Drawing.Point(39, 505);
            this.dgvOutput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvOutput.Name = "dgvOutput";
            this.dgvOutput.RowHeadersWidth = 51;
            this.dgvOutput.Size = new System.Drawing.Size(1603, 272);
            this.dgvOutput.TabIndex = 3;
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(36, 485);
            this.lblOutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(77, 16);
            this.lblOutput.TabIndex = 4;
            this.lblOutput.Text = "RECORDS:";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.SkyBlue;
            this.btnClose.Location = new System.Drawing.Point(1512, 784);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(129, 52);
            this.btnClose.TabIndex = 15;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // child
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1657, 850);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.dgvOutput);
            this.Controls.Add(this.gbxDisplay);
            this.Controls.Add(this.gbInsertUpdate);
            this.Controls.Add(this.lblHeading);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "child";
            this.Text = "child";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbInsertUpdate.ResumeLayout(false);
            this.gbInsertUpdate.PerformLayout();
            this.gbxDisplay.ResumeLayout(false);
            this.gbSort.ResumeLayout(false);
            this.gbSort.PerformLayout();
            this.gbShow.ResumeLayout(false);
            this.gbShow.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrSortAgeII)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmrSortAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.GroupBox gbInsertUpdate;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblIsAccepeted;
        private System.Windows.Forms.Label lblDepart;
        private System.Windows.Forms.Label lblArr;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.ComboBox cmbAccept;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button lblSubmit;
        private System.Windows.Forms.GroupBox gbxDisplay;
        private System.Windows.Forms.GroupBox gbShow;
        private System.Windows.Forms.GroupBox gbSort;
        private System.Windows.Forms.RadioButton rbtnRejected;
        private System.Windows.Forms.RadioButton rbtnAccepted;
        private System.Windows.Forms.RadioButton rbtnAll;
        private System.Windows.Forms.RadioButton rbtnSortArrDesc;
        private System.Windows.Forms.RadioButton rbtnSortArr;
        private System.Windows.Forms.RadioButton rbtnSortAgeDesc;
        private System.Windows.Forms.RadioButton rbtnSortAge;
        private System.Windows.Forms.RadioButton rbtnSortLName;
        private System.Windows.Forms.RadioButton rbtnSortDepartDesc;
        private System.Windows.Forms.RadioButton rbtnSortDepart;
        private System.Windows.Forms.Label lblDepartBtwn;
        private System.Windows.Forms.Label lblArrivedBtwn;
        private System.Windows.Forms.Label lblAgeBtwn;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.DataGridView dgvOutput;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblAND;
        private System.Windows.Forms.DateTimePicker dtmDepart;
        private System.Windows.Forms.DateTimePicker dtmArr;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.DateTimePicker dtmSortDepartII;
        private System.Windows.Forms.DateTimePicker dtmSortDepart;
        private System.Windows.Forms.DateTimePicker dtmSortArrII;
        private System.Windows.Forms.DateTimePicker dtmSortArr;
        private System.Windows.Forms.NumericUpDown nmrSortAgeII;
        private System.Windows.Forms.NumericUpDown nmrSortAge;
        private System.Windows.Forms.Label lblRequired;
    }
}

