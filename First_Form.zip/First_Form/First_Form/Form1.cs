﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace First_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            String Mpassword = "224641";
            String MuserName = "Linda03";
            String Apassword = "996394";
            String AuserName = "Isabel22";

            String password = txtPassword.Text;
            String username = txtUsername.Text;
            String selectedText = comboBox1.SelectedItem.ToString();
            Acces_Forms nextForm = new Acces_Forms();
            if (selectedText == "Manager")
            {
                if (Mpassword == password && MuserName == username)
                {
                    MessageBox.Show("Access granted");
                    nextForm.ShowDialog();
                    
                    this.Close();
                    nextForm.btnDonations.Visible = true;

                }
                else
                {
                    MessageBox.Show("Can not grant access");



                }
            }
            else if (selectedText == "Administrator")
            {
                if (Apassword == password && AuserName == username)
                {
                    nextForm.ShowDialog();

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Can not grant access");
                }



            }
            else
            {
                MessageBox.Show("Select user from comboBox!");
            }








        }



    }


    }

