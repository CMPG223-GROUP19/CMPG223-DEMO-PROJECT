﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Children
{
    public partial class Children : Form
    {
        public Children()
        {
            InitializeComponent();
        }
        //SqlConnection cnn;
        string sql ="";
        SqlCommand command;
        SqlDataAdapter adp;
        DataSet dset;
        String cnnString = @"Data Source=DESKTOP-NFU61V4\SQLEXPRESS;Initial Catalog=TawandaSystem;Integrated Security=True";

        
        private void Form1_Load(object sender, EventArgs e)
        {
            
            //making control invisible
            lblRequired.Visible = false;

            //changing the date format to short
            dtmArr.Format = DateTimePickerFormat.Short;
            dtmDepart.Format = DateTimePickerFormat.Short;
            dtmSortArr.Format = DateTimePickerFormat.Short;
            dtmSortArrII.Format = DateTimePickerFormat.Short;
            dtmSortDepart.Format = DateTimePickerFormat.Short;
            dtmSortDepartII.Format = DateTimePickerFormat.Short;

            //clearing datagridview
            dgvOutput.DataSource = null;
        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }

        private void lblDepart_Click(object sender, EventArgs e)
        {

        }

        private void lblArrivedBtwn_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close(); //closing form
        }

        private void rbtnSortLName_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            //clear text fields
            txtName.Text = "";
            txtLastName.Text = "";
            txtID.Text = "";

            //set datepicker fields to current date
            dtmArr.Value = DateTime.Now;
            dtmDepart.Value = DateTime.Now;
            dtmSortArr.Value = DateTime.Now;
            dtmSortArrII.Value = DateTime.Now;
            dtmSortDepart.Value = DateTime.Now;
            dtmSortDepartII.Value = DateTime.Now;

            //set the age value to minimum value
            nmrSortAge.Value = 0;
            nmrSortAgeII.Value = 0;

            //making required field symbol disappear
            lblRequired.Visible = false;

            //clearing radiobuttons
            rbtnSortAgeDesc.Checked = false;
            rbtnFemale.Checked = false;
            rbtnAccepted.Checked = false;
            rbtnAll.Checked = false;
            rbtnMale.Checked = false;
            rbtnRejected.Checked = false;
            rbtnSortAge.Checked = false;
            rbtnSortArr.Checked = false;
            rbtnSortArrDesc.Checked = false;
            rbtnSortLName.Checked = false;
            rbtnSortDepart.Checked = false;
            rbtnSortDepartDesc.Checked = false;

        }

        private void lblSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection(cnnString);
                cnn.Open();

                adp = new SqlDataAdapter();
                command = new SqlCommand(sql, cnn);

                string dateArrived = dtmArr.Text;
                string isAccepted = cmbAccept.SelectedItem.ToString();


                if (txtName.Text == " " || txtLastName.Text == " " || txtID.Text == " " || cmbAccept.SelectedIndex == -1) //checking if all required fields were entered
                {
                    MessageBox.Show("Please enter all required fields"); //exception handling
                }
                else
                {

                    sql = $"INSERT INTO Child_tbl VALUES ('{txtName.Text}','{txtLastName.Text}','{txtID.Text}','dateArrived','isAccepted')";

                    adp.InsertCommand = command;
                    adp.InsertCommand.ExecuteNonQuery();

                    MessageBox.Show("Information Successfully Submitted ");
                }

                cnn.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Error "+ex); //exception handling
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try //try catch not needed?????
            {
                //load new form
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Error "+ ex); //exception handling
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            try 
            {
                SqlConnection cnn = new SqlConnection(cnnString);
                cnn.Open();
                adp = new SqlDataAdapter();
                dset = new DataSet();

                decimal age1 = nmrSortAge.Value;
                decimal age2 = nmrSortAgeII.Value;

                if (!rbtnAll.Checked && !rbtnAccepted.Checked && !rbtnRejected.Checked && !rbtnFemale.Checked && !rbtnMale.Checked)
                {
                    MessageBox.Show("Select required field"); //exception handling
                    lblRequired.Visible = true;
 
                }
                else
                {
                    if(rbtnAll.Checked) //if user wants to display records of all children
                    {
                        if(rbtnSortLName.Checked)
                        {
                            sql = "SELECT * FROM Child_tbl ORDER BY Child_LName ASC";

                        }
                        else
                        {
                            if((age1 != age2) && (age1 < age2))
                            {
                                
                                //sql = "SELECT * FROM Child_tbl WHERE"
                            }
                            sql = "SELECT * FROM Child_tbl";
                        }

                    }
                    else if(rbtnAccepted.Checked) //if user wants to display records of accepted children only
                    {
                        /*if(///)
                        {

                        }
                        else
                        {

                        }*/
                        //SQL SELECT * FROM TABLE something
                    }
                    else if (rbtnRejected.Checked) //if user wants to display records of rejected children only
                    {
                        //SQL SELECT * FROM TABLE something
                    }
                    else if (rbtnFemale.Checked) //if user wants to display records of female children only
                    {
                        //SQL SELECT * FROM TABLE something
                    }
                    else if (rbtnMale.Checked) //if user wants to display records of male children only
                    {
                        //SQL SELECT * FROM TABLE something
                    }
                }

                command = new SqlCommand(sql, cnn);
                adp.SelectCommand = command;
                adp.Fill(dset, "TawandaSystem");

                dgvOutput.DataSource = dset;
                dgvOutput.DataMember = "TawandaSystem";

                cnn.Close();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Error "+ex); //exception handling
            }
        }
    }
}
