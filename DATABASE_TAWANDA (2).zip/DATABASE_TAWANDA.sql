insert into dbo.LOGIN (User_Name, User_passwords,User_Role)
Values
	('Linda@03', '#Man0003', 'Manager'),
	('Mpho@66', '#Admin66', 'Administrator');