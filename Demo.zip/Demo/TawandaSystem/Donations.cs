﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TawandaSystem
{
    public partial class Donations : Form
    {
        public Donations()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSponsorLName.Clear();
            txtSponsorName.Clear();
            txtEmailAddress.Clear();
            txtPhoneNumber.Clear();
            txtDescription.Clear();
            numAmountQty.Value = 0;
            lstOutput.Items.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccessControl access = new AccessControl();
            access.Show();

        }

        private void btnClearUp_Click(object sender, EventArgs e)
        {
            txtDepartmentUp.Clear();
            txtDescriptionUp.Clear();
            txtEmailAddressUp.Clear();
            txtPhoneNum.Clear();
            txtLNameUp.Clear();
            txtNameUp.Clear();
            numAmountUp.Value = 0;
        }

        private void btnBackUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccessControl access = new AccessControl();
            access.Show();
        }

        private void btnClearDel_Click(object sender, EventArgs e)
        {
            txtLNameDel.Clear();
            txtNameDel.Clear();
            txtDonationTDel.Clear();
            txtDescriptionDel.Clear();
            dgvDeleteRecord.DataSource = null;
        }

        private void btnBackDel_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccessControl access = new AccessControl();
            access.Show();
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            String sponsorLName = txtSponsorLName.Text;
            String sponsorName = txtSponsorName.Text;
            String emailAdress = txtEmailAddress.Text;
            String phoneNum = txtPhoneNumber.Text;
            String description = txtDescription.Text;
            int amount = int.Parse(numAmountQty.Text);
            String dType = comboBox1.SelectedItem.ToString();
            DateTime dateReceived = dateTimePickerDreceived.Value;
            String quantity = txtDonationTDel.Text;

            //using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                //conn.open();
                /* String query = "INSERT INTO DONATION(Date_Received,Amount,Quantity) values(@dateReceived,@amount,@quantity)";
                 SqlCommand comm = new SqlCommand(query, conn);
                 comm.parameters.AddWithValue("@Date_Received" ,dateReceived );
                 comm.parameters.AddWithValue("@Amount" ,amount );
                 comm.parameters.AddWithValue("Quantity" ,quantity);
                 command.ExecuteNonQuery();*/
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /* String sponsorLName = txtSponsorLName.Text;
             String sponsorName = txtSponsorName.Text;
             String emailAdress = txtEmailAddress.Text;
             String phoneNum = txtPhoneNumber.Text;
             String description = txtDescription.Text;
             String department = txtDepartment.Text;
             int amount = int.Parse(numAmount.Text);
             using (SqlConnection conn = new SqlConnection(_connectionString))
             {
                 conn.open();
                 String query = "INSERT INTO Donation_tbl() values(@)";
                 SqlCommand comm = new SqlCommand(query, conn);
                 comm.parameters.AddWithValue("@", );
                 command.ExecuteNonQuery();
             }*/
        }

        private void gbvDonations_Enter(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            String descriptiondl = txtDescriptionDel.Text;
            String donationT = txtDonationTDel.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.open();
                SqlCommand comm = new SqlCommand("SELECT * FROM Donation WHERE cOLUMNnAME= @descriptiondl, coulmnName = @donationT", conn);
                comm.Parameters.AddWithValue("@", descriptiondl);
                comm.Prameters.AddWithValue("@", donationT);

                SqlDataAdapter adpt = new SqlDataAdapter(comm);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dgvDeleteRecord.DataSource = dt;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            String descriptiondl = txtDescriptionDel.Text;
            String donationT = txtDonationTDel.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.open();
                SqlCommand comm = new SqlCommand("DELETE FROM Donation WHERE cOLUMNnAME= @descriptiondl, coulmnName = @donationT", conn);
                comm.Parameters.AddWithValue("@", descriptiondl);
                comm.Prameters.AddWithValue("@", donationT);

                
            }


        }
    }
}
