﻿namespace TawandaSystem
{
    partial class Children
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tpgChildren = new System.Windows.Forms.TabControl();
            this.tpgAdd = new System.Windows.Forms.TabPage();
            this.tpgUpdate = new System.Windows.Forms.TabPage();
            this.tpgDelete = new System.Windows.Forms.TabPage();
            this.lblChildName = new System.Windows.Forms.Label();
            this.lblChildLName = new System.Windows.Forms.Label();
            this.lblHeading = new System.Windows.Forms.Label();
            this.gbInsertRecords = new System.Windows.Forms.GroupBox();
            this.lblID = new System.Windows.Forms.Label();
            this.lblArrival = new System.Windows.Forms.Label();
            this.chbxYes = new System.Windows.Forms.CheckBox();
            this.chbxNo = new System.Windows.Forms.CheckBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.gbIsAccepted = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnBack = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtIDUp = new System.Windows.Forms.TextBox();
            this.txtNameUp = new System.Windows.Forms.TextBox();
            this.txtLNameUp = new System.Windows.Forms.TextBox();
            this.lblDeparture = new System.Windows.Forms.Label();
            this.lblIDUp = new System.Windows.Forms.Label();
            this.lblLNameUp = new System.Windows.Forms.Label();
            this.lblNameUp = new System.Windows.Forms.Label();
            this.lblHeadingII = new System.Windows.Forms.Label();
            this.lstUpdatedRecord = new System.Windows.Forms.ListBox();
            this.lblUpdated = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBackUp = new System.Windows.Forms.Button();
            this.lblHeadingIII = new System.Windows.Forms.Label();
            this.gbSearchToDel = new System.Windows.Forms.GroupBox();
            this.txtNameDel = new System.Windows.Forms.TextBox();
            this.txtLNameDel = new System.Windows.Forms.TextBox();
            this.lblLNameDel = new System.Windows.Forms.Label();
            this.lblNameDel = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnBackDel = new System.Windows.Forms.Button();
            this.dgvDeleteRecord = new System.Windows.Forms.DataGridView();
            this.lblResults = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnClearUp = new System.Windows.Forms.Button();
            this.btnClearDel = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tpgChildren.SuspendLayout();
            this.tpgAdd.SuspendLayout();
            this.tpgUpdate.SuspendLayout();
            this.tpgDelete.SuspendLayout();
            this.gbInsertRecords.SuspendLayout();
            this.gbIsAccepted.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbSearchToDel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteRecord)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpgChildren
            // 
            this.tpgChildren.Controls.Add(this.tpgAdd);
            this.tpgChildren.Controls.Add(this.tpgUpdate);
            this.tpgChildren.Controls.Add(this.tpgDelete);
            this.tpgChildren.Location = new System.Drawing.Point(-2, 24);
            this.tpgChildren.Name = "tpgChildren";
            this.tpgChildren.SelectedIndex = 0;
            this.tpgChildren.Size = new System.Drawing.Size(629, 400);
            this.tpgChildren.TabIndex = 0;
            // 
            // tpgAdd
            // 
            this.tpgAdd.Controls.Add(this.btnClear);
            this.tpgAdd.Controls.Add(this.btnBack);
            this.tpgAdd.Controls.Add(this.gbInsertRecords);
            this.tpgAdd.Controls.Add(this.btnAdd);
            this.tpgAdd.Controls.Add(this.lblHeading);
            this.tpgAdd.Location = new System.Drawing.Point(4, 22);
            this.tpgAdd.Name = "tpgAdd";
            this.tpgAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tpgAdd.Size = new System.Drawing.Size(621, 374);
            this.tpgAdd.TabIndex = 0;
            this.tpgAdd.Text = "Add New Records";
            this.tpgAdd.UseVisualStyleBackColor = true;
            // 
            // tpgUpdate
            // 
            this.tpgUpdate.Controls.Add(this.btnClearUp);
            this.tpgUpdate.Controls.Add(this.btnBackUp);
            this.tpgUpdate.Controls.Add(this.btnUpdate);
            this.tpgUpdate.Controls.Add(this.lblHeadingII);
            this.tpgUpdate.Controls.Add(this.groupBox1);
            this.tpgUpdate.Location = new System.Drawing.Point(4, 22);
            this.tpgUpdate.Name = "tpgUpdate";
            this.tpgUpdate.Padding = new System.Windows.Forms.Padding(3);
            this.tpgUpdate.Size = new System.Drawing.Size(621, 375);
            this.tpgUpdate.TabIndex = 1;
            this.tpgUpdate.Text = "Update Records";
            this.tpgUpdate.UseVisualStyleBackColor = true;
            // 
            // tpgDelete
            // 
            this.tpgDelete.Controls.Add(this.btnClearDel);
            this.tpgDelete.Controls.Add(this.btnSearch);
            this.tpgDelete.Controls.Add(this.btnBackDel);
            this.tpgDelete.Controls.Add(this.btnDelete);
            this.tpgDelete.Controls.Add(this.gbSearchToDel);
            this.tpgDelete.Controls.Add(this.lblHeadingIII);
            this.tpgDelete.Location = new System.Drawing.Point(4, 22);
            this.tpgDelete.Name = "tpgDelete";
            this.tpgDelete.Size = new System.Drawing.Size(621, 375);
            this.tpgDelete.TabIndex = 2;
            this.tpgDelete.Text = "Delete Records";
            this.tpgDelete.UseVisualStyleBackColor = true;
            this.tpgDelete.Click += new System.EventHandler(this.tpgDelete_Click);
            // 
            // lblChildName
            // 
            this.lblChildName.AutoSize = true;
            this.lblChildName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChildName.Location = new System.Drawing.Point(18, 88);
            this.lblChildName.Name = "lblChildName";
            this.lblChildName.Size = new System.Drawing.Size(58, 15);
            this.lblChildName.TabIndex = 0;
            this.lblChildName.Text = "Name(s):";
            // 
            // lblChildLName
            // 
            this.lblChildLName.AutoSize = true;
            this.lblChildLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChildLName.Location = new System.Drawing.Point(18, 63);
            this.lblChildLName.Name = "lblChildLName";
            this.lblChildLName.Size = new System.Drawing.Size(73, 15);
            this.lblChildLName.TabIndex = 1;
            this.lblChildLName.Text = "Last Name: ";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(174, 16);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(229, 20);
            this.lblHeading.TabIndex = 3;
            this.lblHeading.Text = "CHILD MANAGEMENT";
            // 
            // gbInsertRecords
            // 
            this.gbInsertRecords.Controls.Add(this.dateTimePicker1);
            this.gbInsertRecords.Controls.Add(this.gbIsAccepted);
            this.gbInsertRecords.Controls.Add(this.txtID);
            this.gbInsertRecords.Controls.Add(this.txtName);
            this.gbInsertRecords.Controls.Add(this.txtLName);
            this.gbInsertRecords.Controls.Add(this.lblArrival);
            this.gbInsertRecords.Controls.Add(this.lblID);
            this.gbInsertRecords.Controls.Add(this.lblChildLName);
            this.gbInsertRecords.Controls.Add(this.lblChildName);
            this.gbInsertRecords.Location = new System.Drawing.Point(27, 51);
            this.gbInsertRecords.Name = "gbInsertRecords";
            this.gbInsertRecords.Size = new System.Drawing.Size(572, 261);
            this.gbInsertRecords.TabIndex = 4;
            this.gbInsertRecords.TabStop = false;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(18, 112);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(127, 15);
            this.lblID.TabIndex = 2;
            this.lblID.Text = "Identification Number:";
            // 
            // lblArrival
            // 
            this.lblArrival.AutoSize = true;
            this.lblArrival.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArrival.Location = new System.Drawing.Point(17, 137);
            this.lblArrival.Name = "lblArrival";
            this.lblArrival.Size = new System.Drawing.Size(72, 15);
            this.lblArrival.TabIndex = 3;
            this.lblArrival.Text = "Arrival Date:";
            // 
            // chbxYes
            // 
            this.chbxYes.AutoSize = true;
            this.chbxYes.Location = new System.Drawing.Point(19, 23);
            this.chbxYes.Name = "chbxYes";
            this.chbxYes.Size = new System.Drawing.Size(44, 17);
            this.chbxYes.TabIndex = 5;
            this.chbxYes.Text = "Yes";
            this.chbxYes.UseVisualStyleBackColor = true;
            // 
            // chbxNo
            // 
            this.chbxNo.AutoSize = true;
            this.chbxNo.Location = new System.Drawing.Point(19, 46);
            this.chbxNo.Name = "chbxNo";
            this.chbxNo.Size = new System.Drawing.Size(40, 17);
            this.chbxNo.TabIndex = 6;
            this.chbxNo.Text = "No";
            this.chbxNo.UseVisualStyleBackColor = true;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(151, 54);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(100, 20);
            this.txtLName.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(151, 83);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 8;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(151, 111);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(100, 20);
            this.txtID.TabIndex = 9;
            // 
            // gbIsAccepted
            // 
            this.gbIsAccepted.Controls.Add(this.chbxYes);
            this.gbIsAccepted.Controls.Add(this.chbxNo);
            this.gbIsAccepted.Location = new System.Drawing.Point(289, 54);
            this.gbIsAccepted.Name = "gbIsAccepted";
            this.gbIsAccepted.Size = new System.Drawing.Size(263, 99);
            this.gbIsAccepted.TabIndex = 11;
            this.gbIsAccepted.TabStop = false;
            this.gbIsAccepted.Text = "Is Accepeted";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.SkyBlue;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAdd.Location = new System.Drawing.Point(239, 328);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(116, 36);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(151, 137);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.SkyBlue;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBack.Location = new System.Drawing.Point(483, 328);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 36);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblUpdated);
            this.groupBox1.Controls.Add(this.lstUpdatedRecord);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.txtIDUp);
            this.groupBox1.Controls.Add(this.txtNameUp);
            this.groupBox1.Controls.Add(this.txtLNameUp);
            this.groupBox1.Controls.Add(this.lblDeparture);
            this.groupBox1.Controls.Add(this.lblIDUp);
            this.groupBox1.Controls.Add(this.lblLNameUp);
            this.groupBox1.Controls.Add(this.lblNameUp);
            this.groupBox1.Location = new System.Drawing.Point(31, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(565, 268);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(151, 110);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker2.TabIndex = 13;
            // 
            // txtIDUp
            // 
            this.txtIDUp.Location = new System.Drawing.Point(151, 79);
            this.txtIDUp.Name = "txtIDUp";
            this.txtIDUp.Size = new System.Drawing.Size(100, 20);
            this.txtIDUp.TabIndex = 9;
            // 
            // txtNameUp
            // 
            this.txtNameUp.Location = new System.Drawing.Point(151, 54);
            this.txtNameUp.Name = "txtNameUp";
            this.txtNameUp.Size = new System.Drawing.Size(100, 20);
            this.txtNameUp.TabIndex = 8;
            // 
            // txtLNameUp
            // 
            this.txtLNameUp.Location = new System.Drawing.Point(151, 31);
            this.txtLNameUp.Name = "txtLNameUp";
            this.txtLNameUp.Size = new System.Drawing.Size(100, 20);
            this.txtLNameUp.TabIndex = 7;
            // 
            // lblDeparture
            // 
            this.lblDeparture.AutoSize = true;
            this.lblDeparture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeparture.Location = new System.Drawing.Point(17, 110);
            this.lblDeparture.Name = "lblDeparture";
            this.lblDeparture.Size = new System.Drawing.Size(94, 15);
            this.lblDeparture.TabIndex = 3;
            this.lblDeparture.Text = "Departure Date:";
            // 
            // lblIDUp
            // 
            this.lblIDUp.AutoSize = true;
            this.lblIDUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDUp.Location = new System.Drawing.Point(16, 84);
            this.lblIDUp.Name = "lblIDUp";
            this.lblIDUp.Size = new System.Drawing.Size(127, 15);
            this.lblIDUp.TabIndex = 2;
            this.lblIDUp.Text = "Identification Number:";
            // 
            // lblLNameUp
            // 
            this.lblLNameUp.AutoSize = true;
            this.lblLNameUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLNameUp.Location = new System.Drawing.Point(16, 36);
            this.lblLNameUp.Name = "lblLNameUp";
            this.lblLNameUp.Size = new System.Drawing.Size(73, 15);
            this.lblLNameUp.TabIndex = 1;
            this.lblLNameUp.Text = "Last Name: ";
            // 
            // lblNameUp
            // 
            this.lblNameUp.AutoSize = true;
            this.lblNameUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameUp.Location = new System.Drawing.Point(16, 59);
            this.lblNameUp.Name = "lblNameUp";
            this.lblNameUp.Size = new System.Drawing.Size(58, 15);
            this.lblNameUp.TabIndex = 0;
            this.lblNameUp.Text = "Name(s):";
            // 
            // lblHeadingII
            // 
            this.lblHeadingII.AutoSize = true;
            this.lblHeadingII.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeadingII.Location = new System.Drawing.Point(173, 18);
            this.lblHeadingII.Name = "lblHeadingII";
            this.lblHeadingII.Size = new System.Drawing.Size(229, 20);
            this.lblHeadingII.TabIndex = 6;
            this.lblHeadingII.Text = "CHILD MANAGEMENT";
            // 
            // lstUpdatedRecord
            // 
            this.lstUpdatedRecord.FormattingEnabled = true;
            this.lstUpdatedRecord.Location = new System.Drawing.Point(274, 48);
            this.lstUpdatedRecord.Name = "lstUpdatedRecord";
            this.lstUpdatedRecord.Size = new System.Drawing.Size(285, 212);
            this.lstUpdatedRecord.TabIndex = 14;
            // 
            // lblUpdated
            // 
            this.lblUpdated.AutoSize = true;
            this.lblUpdated.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdated.Location = new System.Drawing.Point(271, 30);
            this.lblUpdated.Name = "lblUpdated";
            this.lblUpdated.Size = new System.Drawing.Size(100, 15);
            this.lblUpdated.TabIndex = 15;
            this.lblUpdated.Text = "Updated Record:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.SkyBlue;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdate.Location = new System.Drawing.Point(236, 315);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(116, 36);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnBackUp
            // 
            this.btnBackUp.BackColor = System.Drawing.Color.SkyBlue;
            this.btnBackUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackUp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBackUp.Location = new System.Drawing.Point(480, 315);
            this.btnBackUp.Name = "btnBackUp";
            this.btnBackUp.Size = new System.Drawing.Size(116, 36);
            this.btnBackUp.TabIndex = 14;
            this.btnBackUp.Text = "Back";
            this.btnBackUp.UseVisualStyleBackColor = false;
            // 
            // lblHeadingIII
            // 
            this.lblHeadingIII.AutoSize = true;
            this.lblHeadingIII.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeadingIII.Location = new System.Drawing.Point(171, 24);
            this.lblHeadingIII.Name = "lblHeadingIII";
            this.lblHeadingIII.Size = new System.Drawing.Size(229, 20);
            this.lblHeadingIII.TabIndex = 7;
            this.lblHeadingIII.Text = "CHILD MANAGEMENT";
            // 
            // gbSearchToDel
            // 
            this.gbSearchToDel.Controls.Add(this.lblResults);
            this.gbSearchToDel.Controls.Add(this.dgvDeleteRecord);
            this.gbSearchToDel.Controls.Add(this.txtNameDel);
            this.gbSearchToDel.Controls.Add(this.txtLNameDel);
            this.gbSearchToDel.Controls.Add(this.lblLNameDel);
            this.gbSearchToDel.Controls.Add(this.lblNameDel);
            this.gbSearchToDel.Location = new System.Drawing.Point(31, 47);
            this.gbSearchToDel.Name = "gbSearchToDel";
            this.gbSearchToDel.Size = new System.Drawing.Size(564, 248);
            this.gbSearchToDel.TabIndex = 8;
            this.gbSearchToDel.TabStop = false;
            this.gbSearchToDel.Text = "Search for Record:";
            // 
            // txtNameDel
            // 
            this.txtNameDel.Location = new System.Drawing.Point(110, 52);
            this.txtNameDel.Name = "txtNameDel";
            this.txtNameDel.Size = new System.Drawing.Size(100, 20);
            this.txtNameDel.TabIndex = 8;
            // 
            // txtLNameDel
            // 
            this.txtLNameDel.Location = new System.Drawing.Point(110, 26);
            this.txtLNameDel.Name = "txtLNameDel";
            this.txtLNameDel.Size = new System.Drawing.Size(100, 20);
            this.txtLNameDel.TabIndex = 7;
            // 
            // lblLNameDel
            // 
            this.lblLNameDel.AutoSize = true;
            this.lblLNameDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLNameDel.Location = new System.Drawing.Point(16, 31);
            this.lblLNameDel.Name = "lblLNameDel";
            this.lblLNameDel.Size = new System.Drawing.Size(73, 15);
            this.lblLNameDel.TabIndex = 1;
            this.lblLNameDel.Text = "Last Name: ";
            // 
            // lblNameDel
            // 
            this.lblNameDel.AutoSize = true;
            this.lblNameDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameDel.Location = new System.Drawing.Point(16, 57);
            this.lblNameDel.Name = "lblNameDel";
            this.lblNameDel.Size = new System.Drawing.Size(58, 15);
            this.lblNameDel.TabIndex = 0;
            this.lblNameDel.Text = "Name(s):";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.SkyBlue;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDelete.Location = new System.Drawing.Point(345, 315);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(116, 36);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnBackDel
            // 
            this.btnBackDel.BackColor = System.Drawing.Color.SkyBlue;
            this.btnBackDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackDel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnBackDel.Location = new System.Drawing.Point(479, 315);
            this.btnBackDel.Name = "btnBackDel";
            this.btnBackDel.Size = new System.Drawing.Size(116, 36);
            this.btnBackDel.TabIndex = 15;
            this.btnBackDel.Text = "Back";
            this.btnBackDel.UseVisualStyleBackColor = false;
            this.btnBackDel.Click += new System.EventHandler(this.btnBackDel_Click);
            // 
            // dgvDeleteRecord
            // 
            this.dgvDeleteRecord.AllowUserToOrderColumns = true;
            this.dgvDeleteRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeleteRecord.Location = new System.Drawing.Point(19, 100);
            this.dgvDeleteRecord.Name = "dgvDeleteRecord";
            this.dgvDeleteRecord.Size = new System.Drawing.Size(527, 132);
            this.dgvDeleteRecord.TabIndex = 9;
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(16, 82);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(93, 15);
            this.lblResults.TabIndex = 10;
            this.lblResults.Text = "Search Results:";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.SkyBlue;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSearch.Location = new System.Drawing.Point(101, 315);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(116, 36);
            this.btnSearch.TabIndex = 16;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.SkyBlue;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClear.Location = new System.Drawing.Point(361, 328);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(116, 36);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            // 
            // btnClearUp
            // 
            this.btnClearUp.BackColor = System.Drawing.Color.SkyBlue;
            this.btnClearUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearUp.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClearUp.Location = new System.Drawing.Point(358, 315);
            this.btnClearUp.Name = "btnClearUp";
            this.btnClearUp.Size = new System.Drawing.Size(116, 36);
            this.btnClearUp.TabIndex = 15;
            this.btnClearUp.Text = "Clear";
            this.btnClearUp.UseVisualStyleBackColor = false;
            // 
            // btnClearDel
            // 
            this.btnClearDel.BackColor = System.Drawing.Color.SkyBlue;
            this.btnClearDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearDel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnClearDel.Location = new System.Drawing.Point(223, 315);
            this.btnClearDel.Name = "btnClearDel";
            this.btnClearDel.Size = new System.Drawing.Size(116, 36);
            this.btnClearDel.TabIndex = 17;
            this.btnClearDel.Text = "Clear";
            this.btnClearDel.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Right;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(584, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(44, 426);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(113, 19);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // Children
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(628, 426);
            this.Controls.Add(this.tpgChildren);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Children";
            this.Text = "Children";
            this.tpgChildren.ResumeLayout(false);
            this.tpgAdd.ResumeLayout(false);
            this.tpgAdd.PerformLayout();
            this.tpgUpdate.ResumeLayout(false);
            this.tpgUpdate.PerformLayout();
            this.tpgDelete.ResumeLayout(false);
            this.tpgDelete.PerformLayout();
            this.gbInsertRecords.ResumeLayout(false);
            this.gbInsertRecords.PerformLayout();
            this.gbIsAccepted.ResumeLayout(false);
            this.gbIsAccepted.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbSearchToDel.ResumeLayout(false);
            this.gbSearchToDel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteRecord)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tpgChildren;
        private System.Windows.Forms.TabPage tpgAdd;
        private System.Windows.Forms.TabPage tpgUpdate;
        private System.Windows.Forms.TabPage tpgDelete;
        private System.Windows.Forms.Label lblChildLName;
        private System.Windows.Forms.Label lblChildName;
        private System.Windows.Forms.GroupBox gbInsertRecords;
        private System.Windows.Forms.Label lblArrival;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.CheckBox chbxNo;
        private System.Windows.Forms.CheckBox chbxYes;
        private System.Windows.Forms.GroupBox gbIsAccepted;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblHeadingII;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox txtIDUp;
        private System.Windows.Forms.TextBox txtNameUp;
        private System.Windows.Forms.TextBox txtLNameUp;
        private System.Windows.Forms.Label lblDeparture;
        private System.Windows.Forms.Label lblIDUp;
        private System.Windows.Forms.Label lblLNameUp;
        private System.Windows.Forms.Label lblNameUp;
        private System.Windows.Forms.Button btnBackUp;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblUpdated;
        private System.Windows.Forms.ListBox lstUpdatedRecord;
        private System.Windows.Forms.Label lblHeadingIII;
        private System.Windows.Forms.GroupBox gbSearchToDel;
        private System.Windows.Forms.TextBox txtNameDel;
        private System.Windows.Forms.TextBox txtLNameDel;
        private System.Windows.Forms.Label lblLNameDel;
        private System.Windows.Forms.Label lblNameDel;
        private System.Windows.Forms.Button btnBackDel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView dgvDeleteRecord;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnClearUp;
        private System.Windows.Forms.Button btnClearDel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}