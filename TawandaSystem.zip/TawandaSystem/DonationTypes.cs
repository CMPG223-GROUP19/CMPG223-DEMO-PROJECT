﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TawandaSystem
{
    public partial class DonationTypes : Form
    {
        public DonationTypes()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tpgDonationTDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn;
                string donationType = txtDonationType.Text;
                string donationDescription = txtDonationDescr.Text;

                if (donationType != " " && donationDescription != " ")
                {
                    string connectionString = @"Data Source=SOLS\\SQLEXPRESS;Initial Catalog=TAWANDA;Integrated Security=True;";
                    string query = "INSERT INTO Donations VALUES('donationType','donationDescription')";

                    conn = new SqlConnection(connectionString);
                    {
                        conn.Open();
                        SqlCommand command = new SqlCommand(query, conn);

                        command.Parameters.AddWithValue("@ DonationType", donationType);
                        command.Parameters.AddWithValue("@ DonationDescription", donationDescription);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Data added successfully");
                    }

                }
                else
                {
                    MessageBox.Show("Please enter Donation Type and Donation Description");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDonationType.Clear();
            txtDonationDescr.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AccessControl accessControl = new AccessControl();
            accessControl.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void btnClearUp_Click(object sender, EventArgs e)
        {
            cbxDonationType.SelectedIndex = -1;
            txtDonationDescri.Clear();
        }

        private void btnBackUp_Click(object sender, EventArgs e)
        {
            AccessControl accessControl = new AccessControl();
            accessControl.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to exit", "Confirm", MessageBoxButtons.YesNo);
            if(result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try 
            {
                SqlConnection conn;
                string donationType = txtDonationTDel.Text;

                if (donationType != "" )
                {
                    string connectionString = @"Data Source=SOLS\\SQLEXPRESS;Initial Catalog=TAWANDA;Integrated Security=True;";
                    conn = new SqlConnection(connectionString);
                    {
                        conn.Open();
                        SqlCommand command = new SqlCommand("SELECT * FROM Donations WHERE donationType LIKE @DonationType",conn);
                        command.Parameters.AddWithValue("@ DonationType","%" + donationType + "%");

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dgvDeleteRecord.DataSource = table;
                    }

                }
                else
                {
                    MessageBox.Show("Please enter Donation Type");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn;
                string donationType = txtDonationTDel.Text;

                if (donationType != "")
                {
                    string connectionString = @"Data Source=SOLS\\SQLEXPRESS;Initial Catalog=TAWANDA;Integrated Security=True;";
                    conn = new SqlConnection(connectionString);
                    {
                        conn.Open();
                        SqlCommand command = new SqlCommand("DELETE FROM Donations WHERE donationType LIKE @DonationType", conn);
                        command.Parameters.AddWithValue("@ DonationType",donationType);
                        command.ExecuteNonQuery();
                    }

                }
                else
                {
                    MessageBox.Show("Please enter Donation Type");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void btnClearDel_Click(object sender, EventArgs e)
        {
            txtDonationTDel.Clear();
        }

        private void btnBackDel_Click(object sender, EventArgs e)
        {
            AccessControl accessControl = new AccessControl();
            accessControl.ShowDialog();
        }
    }
}


