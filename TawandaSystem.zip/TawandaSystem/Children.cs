﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TawandaSystem
{
    public partial class Children : Form
    {
        public Children()
        {
            InitializeComponent();
        }

        private void tpgDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnBackDel_Click(object sender, EventArgs e)
        {

        }
    }
}
