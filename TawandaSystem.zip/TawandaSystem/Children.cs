﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TawandaSystem
{
    public partial class Children : Form
    {
        public Children()
        {
            InitializeComponent();
        }

        private bool ValidateIDNum(string idNum) //validating ID number 
        {
            if (idNum.Length != 13)
            {
                return false;
            }

            if (!idNum.All(char.IsDigit))
            {
                return false;
            }

            return true;
        }
        private void tpgDelete_Click(object sender, EventArgs e)
        {

        }

        private void btnBackDel_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AccessControl form = new AccessControl();
            form.ShowDialog();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtLName.Text == " " && txtName.Text == " " && txtID.Text == " " && dateTimePicker1.Value.ToString() == " " && !chbxYes.Checked && !chbxNo.Checked)
                {
                    MessageBox.Show("Please enter all required fields");
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtLName.Text))
                    {
                        MessageBox.Show("Please enter the child's Last Name");
                    }
                    else if (string.IsNullOrWhiteSpace(txtName.Text))
                    {
                        MessageBox.Show("Please enter the child's Name");
                    }
                    else if (!ValidateIDNum(txtID.Text))
                    {
                        MessageBox.Show("Invalid ID Number");

                        if (string.IsNullOrWhiteSpace(txtID.Text))
                        {
                            MessageBox.Show("Please enter the child's identification number");
                        }
                    }
                    else if (!chbxYes.Checked && !chbxNo.Checked)
                    {
                        MessageBox.Show("Please indicate the child's accpetence status");
                    }
                    else if (dateTimePicker1.Value == dateTimePicker1.MinDate)
                    {
                        MessageBox.Show("Please enter a valid arrival date");
                    }
                    else
                    {
                        MessageBox.Show("Successfully submitted");
                    }
                }

            }
            catch(SqlException io)
            {
                MessageBox.Show("An error occured in the system, we apologise for any inconveniences"+io);
            }
        }

        private void tpgAdd_Click(object sender, EventArgs e)
        {
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtLName.Clear();
            txtName.Clear();
            txtID.Clear();
            dateTimePicker1.Value = DateTime.Today;
            chbxNo.Checked = false;
            chbxYes.Checked = false;
        }

        private void Children_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Today;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
