﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Donoation_Types
{
    public partial class InsertDonationTypes : Form
    {
        public InsertDonationTypes()
        {
            InitializeComponent();
        }

        private void InsertDonationTypes_Load(object sender, EventArgs e)
        {
            
        }
    }
}
